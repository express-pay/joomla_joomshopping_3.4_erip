INSERT INTO `#__jshopping_payment_method` (`payment_code`, `scriptname`, `payment_class`, `payment_publish`, `payment_ordering`, `payment_type`, `price`, `price_type`, `tax_id`, `show_descr_in_email`, `name_en-GB`, `name_de-DE`, `name_ru-RU`) VALUES ('erip_expresspay', 'pm_erip_expresspay', 'pm_erip_expresspay', 1, 0, 1, 0.00, 0, 1, 0, 'System "Accounting" ERIP', 'System "Accounting" ERIP', 'Система "Расчет" ЕРИП');
DROP TABLE IF EXISTS `#__jshopping_payment_express_pay`;
CREATE TABLE `#__jshopping_payment_express_pay` (`ru` TEXT, `en` TEXT);
INSERT INTO `#__jshopping_payment_express_pay` (`ru`, `en`) VALUES ('Для оплаты заказа Вам необходимо перейти в раздел ЕРИП:

Интернет-магазины\\Сервисы -> "Первая буква доменного имени интернет-магазина" -> "Доменное имя интернет-магазина"

Далее введите номер заказа "##order_id##" и нажмите "продолжить".

После поступления оплаты Ваш заказ поступит в обработку.', 'To order a payment, you must go to the section ERIP:

Online shops\\Services -> "The first letter of a domain name online store" -> "The domain name is the online store"

Next, enter the order number "##order_id##" and click "continue".

After payment is received your order will go on treatment.');